#!/bin/sh

rm -rfv nuvolasdk.egg-info build dist
