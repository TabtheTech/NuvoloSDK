#!/bin/sh
exec nuvolaruntime -a "@@APP_DIR@@" "$@"
