import sys

import nuvolasdk

sys.exit(nuvolasdk.run(".", sys.argv))
